package ru.vsu.cs.course1;


public class Task {
    public static int[] solution(int[] arr) throws SimpleLinkedList.SimpleLinkedListException {
        SimpleLinkedList<Integer> list = new SimpleLinkedList<>();
        for (int i : arr) {
            list.addLast(i);
        }

        if(list.size()%2 == 1){
            list.addLast(0);
        }

        int size = list.size();

        list.doAction(size/2);

        int[] result = new int[(arr.length + 1)/2];
        for (int i = 0; i < result.length; i++) {
            result[i] = list.get(i);
        }
        return result;
    }
}
